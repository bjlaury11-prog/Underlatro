# UNDERDECK — fan prototype build

A self-contained browser-playable prototype exploring an Undertale × Balatro fan-game concept.

## Play
Open `index.html` in a modern browser. No server or dependencies are required.

## Prototype features
- Poker-hand selection and scoring with Chips × Mult damage
- Joker modifiers
- Tutorial monster battle, redraw, victory, mercy/violence route flags
- Optional tougher expedition encounter
- Lightweight story continuation

## Important publishing limitation
This is **not** a Melty.gg mod package and does not integrate or bundle Undertale or Balatro. The Melty service was not reachable from the build session, so actual game installation, companion-game folder mappings, one-click validation, screenshots from the real game, and publishing remain unverified. Treat this as a standalone prototype/source handoff, not a verified Melty release.

This is an unofficial fan prototype, not affiliated with or endorsed by the rights holders. It contains no official game assets.
